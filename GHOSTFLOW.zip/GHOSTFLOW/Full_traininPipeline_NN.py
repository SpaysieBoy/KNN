import os
import pandas as pd
import numpy as np
from tqdm import tqdm
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.preprocessing import LabelEncoder, LabelBinarizer
from sklearn.base import BaseEstimator, TransformerMixin, ClassifierMixin

from transformers import AutoTokenizer, AutoModel
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

# === BERT-embeddings transformer ===
class BertEmbeddingTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, model_name='emilyalsentzer/Bio_ClinicalBERT', max_length=512, device=None):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModel.from_pretrained(model_name)
        self.max_length = max_length
        self.device = device if device else ('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        self.model.eval()
        embeddings = []
        with torch.no_grad():
            for text in X:
                inputs = self.tokenizer(
                    text,
                    return_tensors='pt',
                    truncation=True,
                    padding='max_length',
                    max_length=self.max_length
                ).to(self.device)
                outputs = self.model(**inputs)
                cls_embedding = outputs.last_hidden_state[:, 0, :].squeeze(0).cpu().numpy()
                embeddings.append(cls_embedding)
        return np.vstack(embeddings)

# === PyTorch NN wrapper als sklearn classifier ===
class TorchNNClassifier(BaseEstimator, ClassifierMixin):
    def __init__(self, input_dim=768, hidden_dim=128, epochs=10, batch_size=32, lr=1e-3, device=None, random_state=42):
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.epochs = epochs
        self.batch_size = batch_size
        self.lr = lr
        self.device = device if device else ('cuda' if torch.cuda.is_available() else 'cpu')
        self.random_state = random_state
        self._is_fitted = False

    def _build_model(self, output_dim):
        class FeedForwardNN(nn.Module):
            def __init__(self, input_dim, hidden_dim, output_dim):
                super().__init__()
                self.network = nn.Sequential(
                    nn.Linear(input_dim, hidden_dim),
                    nn.ReLU(),
                    nn.Dropout(0.2),
                    nn.Linear(hidden_dim, output_dim)
                )
            def forward(self, x):
                return self.network(x)

        self.model = FeedForwardNN(self.input_dim, self.hidden_dim, output_dim).to(self.device)

    def fit(self, X, y):
        torch.manual_seed(self.random_state)
        np.random.seed(self.random_state)

        X = torch.tensor(X, dtype=torch.float32)
        y = torch.tensor(y, dtype=torch.long)
        output_dim = len(np.unique(y.numpy()))

        self._build_model(output_dim)

        dataset = TensorDataset(X, y)
        loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)

        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(self.model.parameters(), lr=self.lr)

        self.model.train()
        for epoch in range(self.epochs):
            epoch_loss = 0
            for xb, yb in loader:
                xb, yb = xb.to(self.device), yb.to(self.device)
                optimizer.zero_grad()
                preds = self.model(xb)
                loss = criterion(preds, yb)
                loss.backward()
                optimizer.step()
                epoch_loss += loss.item()

        self._is_fitted = True
        return self

    def predict(self, X):
        if not self._is_fitted:
            raise RuntimeError("You must train classifier before predicting!")
        self.model.eval()
        X = torch.tensor(X, dtype=torch.float32).to(self.device)
        with torch.no_grad():
            outputs = self.model(X)
            preds = torch.argmax(outputs, dim=1).cpu().numpy()
        return preds

    def predict_proba(self, X):
        if not self._is_fitted:
            raise RuntimeError("You must train classifier before predicting!")
        self.model.eval()
        X = torch.tensor(X, dtype=torch.float32).to(self.device)
        with torch.no_grad():
            outputs = self.model(X)
            probs = torch.softmax(outputs, dim=1).cpu().numpy()
        return probs


# === Externe testbestanden ===
external_test_paths = {
    'feedback by hands': 'Testfolder/Feedback_by_hands_sentiment.csv',
    'Second hospital': 'Testfolder/Subset_Second_Hospital_sentiment.csv',
    'Amazon': 'Testfolder/Subset_Amazon_reviews_sentiment.csv'
}

device = 'cuda' if torch.cuda.is_available() else 'cpu'

# === Hoofdloop over 10 runs ===
for i in tqdm(range(10), desc="Runs voltooid"):
    input_train_path = f"Testfolder/generated_reviews_papagAIo1.0.csv"
    output_path = f"Testfolder/Output/Train in pipeline/NN/Full_PapagAIo_NN_pipeline_{i+1}.txt"

    df = pd.read_csv(input_train_path, sep=";")
    df.columns = ['Sentiment', 'Review']
    df['Review'] = df['Review'].astype(str).str.strip().str.replace('"""', '')
    df['Sentiment'] = df['Sentiment'].str.strip()
    df = df[df['Review'].str.len() > 10]
    if df['Sentiment'].value_counts().get('Neutraal', 0) < 10:
        df = df[df['Sentiment'] != 'Neutraal']

    X = df['Review'].tolist()
    y = df['Sentiment'].tolist()

    # Labels encoden
    le = LabelEncoder()
    y_encoded = le.fit_transform(y)
    classes = le.classes_

    # Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=0.3, stratify=y_encoded, random_state=42+i)

    # Pipeline samenstellen
    pipeline = Pipeline([
        ('bert', BertEmbeddingTransformer(model_name='emilyalsentzer/Bio_ClinicalBERT', device=device)),
        ('clf', TorchNNClassifier(input_dim=768, hidden_dim=128, epochs=10, batch_size=32, device=device, random_state=42+i))
    ])

    # Fit pipeline
    pipeline.fit(X_train, y_train)

    # Predict en evaluatie op PapagAIo testdata
    y_pred = pipeline.predict(X_test)
    y_test_labels = le.inverse_transform(y_test)
    y_pred_labels = le.inverse_transform(y_pred)

    report = classification_report(y_test_labels, y_pred_labels, zero_division=0)
    cm = confusion_matrix(y_test_labels, y_pred_labels, labels=classes)
    conf_matrix_text = f"\n\nConfusion Matrix (PapagAIo):\n{pd.DataFrame(cm, index=classes, columns=classes).to_string()}"

    auc_text = ""
    if len(classes) == 2:
        y_test_bin = y_test  # al 0/1 gecodeerd
        y_scores = pipeline.predict_proba(X_test)[:, 1]
        auc_score = roc_auc_score(y_test_bin, y_scores)
        auc_text = f"\n\nAUC-ROC score (PapagAIo): {auc_score:.4f}"

    results = ["=== EVALUATIE OP PAPAGAIO TESTDATA (NN) ===\n", report, conf_matrix_text, auc_text, "\n"]

    # Evaluatie externe testsets
    for label, path in external_test_paths.items():
        df_ext = pd.read_csv(path)
        df_ext.columns = ['Sentiment', 'Review']
        df_ext['Review'] = df_ext['Review'].astype(str).str.strip().str.replace('"""', '')
        df_ext['Sentiment'] = df_ext['Sentiment'].str.strip()
        df_ext = df_ext[df_ext['Review'].str.len() > 10]
        if df_ext['Sentiment'].value_counts().get('Neutraal', 0) < 10:
            df_ext = df_ext[df_ext['Sentiment'] != 'Neutraal']

        X_ext = df_ext['Review'].tolist()
        y_ext = df_ext['Sentiment'].tolist()

        # Filter onbekende labels
        valid_indices = [idx for idx, lbl in enumerate(y_ext) if lbl in classes]
        X_ext = [X_ext[idx] for idx in valid_indices]
        y_ext = [y_ext[idx] for idx in valid_indices]

        if len(y_ext) == 0:
            ext_report = "⚠️ Geen overlappende klassen met PapagAIo."
            ext_cm = ext_report
            auc_ext = ""
        else:
            y_ext_encoded = le.transform(y_ext)
            y_ext_pred = pipeline.predict(X_ext)
            y_ext_pred_labels = le.inverse_transform(y_ext_pred)

            ext_report = classification_report(y_ext, y_ext_pred_labels, zero_division=0)

            valid_labels = sorted(list(set(y_ext) & set(classes)))
            cm = confusion_matrix(y_ext, y_ext_pred_labels, labels=valid_labels)
            ext_cm = f"\n\nConfusion Matrix {label}:\n{pd.DataFrame(cm, index=valid_labels, columns=valid_labels).to_string()}"

            auc_ext = ""
            if len(classes) == 2:
                y_ext_scores = pipeline.predict_proba(X_ext)[:, 1]
                auc_value = roc_auc_score(y_ext_encoded, y_ext_scores)
                auc_ext = f"\n\nAUC-ROC score {label}: {auc_value:.4f}"

        results.extend([f"\n--- Evaluatie op {label} (100% test) ---\n", ext_report, ext_cm, auc_ext])

    # Resultaten opslaan
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        for line in results:
            f.write(line)

    print(f"✅ Evaluatie Run {i+1} (NN) opgeslagen in: {output_path}")
